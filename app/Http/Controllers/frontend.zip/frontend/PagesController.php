<?php

namespace App\Http\Controllers\frontend;

use App\Models\User;
use App\Models\Order;
use App\Models\Slider;
use App\Models\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class PagesController extends Controller
{
    public function index()
    {
        
        $slider = Slider::where('status', '1')->get();
        return view('frontend.pages.index', compact('slider'));
    }
    public function menus()
    {
        return view('frontend.pages.menus');
    }
    public function cart()
    {
        $cart = session()->get('cart', []);  // sessiondaki cart verisini al
        return view('frontend.pages.cart', compact('cart')); // blade'e gönder
    }

    public function checkout()
    {
        return view('frontend.pages.checkout');
    }
    public function checkoutPost(Request $request)
    {
        $cart = session()->get('cart', []);
        $products = collect($cart)->map(function ($item) {
            return $item['name'] . ' x' . $item['quantity'];
        })->implode(', ');

        $total_price = collect($cart)->reduce(function ($carry, $item) {
            return $carry + ($item['price'] * $item['quantity']);
        }, 0);

        $user = Auth::user();

        Order::create([
            'user_id'     => $user->id,
            'name'        => $user->name,
            'order_number' => str_pad(rand(0, 99999999999), 11, '0', STR_PAD_LEFT),
            'email'       => $user->email,
            'phone'       => $user->phone,
            'adress'      => $user->adress,
            'products'    => $products,
            'total_price' => $total_price,
            'status'      => 'pending',
        ]);

        session()->forget('cart');
        return back()->with('success', 'Siparişiniz başarıyla oluşturuldu!');
    }

    public function myOrders()
    {
        $userId = Auth::id(); // oturumdaki kullanıcının ID'sini al
        $orders = Order::where('user_id', $userId)->latest()->get(); // kullanıcıya ait siparişleri çek
        return view('frontend.pages.myorder', compact('orders'));
    }

    public function productDetail($slug)
    {
        $product = Products::where('slug', $slug)->first();
        return view('frontend.pages.productdetail', compact('product'));
    }
}
