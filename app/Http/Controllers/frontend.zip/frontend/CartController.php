<?php

namespace App\Http\Controllers\frontend;

use App\Models\Products;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CartController extends Controller
{
    public function add(Request $request)
    {
        $product = Products::findOrFail($request->product_id);
        $quantity = $request->quantity ?? 1;

        $cart = session()->get('cart', []);

        if (isset($cart[$product->id])) {
            $cart[$product->id]['quantity'] += $quantity;
        } else {
            $cart[$product->id] = [
                "name" => $product->name,
                "price" => $product->price,
                "image" => $product->image,
                "quantity" => $quantity,
            ];
        }

        session()->put('cart', $cart);

        // Sepeti ekranda göstermek için (örneğin debug amaçlı)
        // return $cart;  // Bu fonksiyonun erken çıkmasına sebep olur, alt satır çalışmaz.

        // Bu şekilde session içeriğini döndürürsün:
        // return response()->json(session()->get('cart'));

        return redirect()->route('cart')->with('success', 'Ürün sepete eklendi.');


        // return redirect()->back()->with('success', 'Ürün sepete eklendi.');
    }
    public function remove(Request $request)
    {
        $productId = $request->input('product_id');
        $cart = session()->get('cart', []);

        if (isset($cart[$productId])) {
            unset($cart[$productId]);
            session()->put('cart', $cart);
        }

        return redirect()->back()->with('success', 'Ürün sepetten kaldırıldı.');
    }
}
